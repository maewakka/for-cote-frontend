import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import MonacoEditor from '@monaco-editor/react';
import styles from '../styles/ProblemDetail.module.css';

const ProblemDetail = () => {
  const { problem_id } = useParams();
  const [problemData, setProblemData] = useState(null);
  const [language, setLanguage] = useState('javascript');
  const [code, setCode] = useState('');
  const [output, setOutput] = useState(''); // 실행 결과
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProblemDetails = async () => {
      try {
        const response = await axios.get(`/api2/problem/${problem_id}`);
        let description = response.data.description;

        // 이미지 태그의 src 속성 앞에 '/api3' 추가
        description = description.replace(/<img\s+[^>]*src="(\/[^"]*)"/g, '<img src="/api3$1"');

        setProblemData({ ...response.data, description });
        setLoading(false);
      } catch (error) {
        console.error('문제 데이터를 불러오는 중 오류 발생:', error);
        setLoading(false);
      }
    };

    fetchProblemDetails();
  }, [problem_id]);

  if (loading) return <div>Loading...</div>;

  const handleLanguageChange = (e) => {
    setLanguage(e.target.value);
  };

  const handleEditorChange = (value) => {
    setCode(value);
  };

  const handleExecuteCode = () => {
    const simulatedOutput = `Code executed with output: ${code.length} characters`;
    setOutput(simulatedOutput);
  };

  return (
    <div className={styles.problemContainer}>
      {/* 문제 설명 영역 */}
      <div className={styles.problemDescription}>
        <h1>{problemData.title}</h1>
        <div
          className={styles.description}
          dangerouslySetInnerHTML={{ __html: problemData.description }}
        ></div>
        <h2>입력</h2>
        <pre>{problemData.input}</pre>
        <h2>출력</h2>
        <pre>{problemData.output}</pre>
      </div>

      {/* 코드 작성 및 실행 결과 영역 */}
      <div className={styles.codeContainer}>
        {/* IDE 영역 */}
        <div className={styles.editor}>
          <div className={styles.languageSelector}>
            <label htmlFor="language">언어 선택: </label>
            <select id="language" value={language} onChange={handleLanguageChange}>
              <option value="javascript">JavaScript</option>
              <option value="cpp">C++</option>
              <option value="python">Python</option>
            </select>
          </div>

          <MonacoEditor
            height="300px"
            language={language}
            value={code}
            theme="vs-dark"
            onChange={handleEditorChange}
            options={{
              selectOnLineNumbers: true,
              automaticLayout: true,
              fontSize: 16,
              minimap: { enabled: false },
            }}
          />

          <div className={styles.ideButtons}>
            <button onClick={handleExecuteCode}>코드 실행</button>
          </div>
        </div>

        {/* 실행 결과 영역 */}
        <div className={styles.output}>
          <h3>실행 결과</h3>
          <pre>{output || '결과가 여기 표시됩니다.'}</pre>
        </div>
      </div>
    </div>
  );
};

export default ProblemDetail;
