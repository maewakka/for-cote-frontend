// src/App.js

import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navigator from './components/Navigator';
import ProblemList from './components/ProblemList';
import StepDetail from './components/StepDetail';
import ProblemDetail from './components/ProblemDetail'; // ProblemDetail 컴포넌트 추가

const App = () => {
  return (
    <Router>
      <div className="container">
        <Navigator />
        <Routes>
          <Route path="/" element={<ProblemList />} />
          <Route path="/step/:step_id" element={<StepDetail />} />
          <Route path="/problem/:problem_id" element={<ProblemDetail />} /> {/* 문제 상세 페이지 라우트 추가 */}
        </Routes>
      </div>
    </Router>
  );
};

export default App;
